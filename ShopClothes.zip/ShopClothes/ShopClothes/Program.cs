﻿using System;
using System.Collections.Generic;
using static ShopClothes.Basket;
using static System.Console;

namespace ShopClothes
{
    class Program
    {
        
        static void Main(string[] args)
        {
            WriteLine("Hello and welcome to Shop Clothes\n");


            var basket = new Basket.Tshirt();
            var tshirt = new Tshirt();
            var pants = new Pants();


            //Tshirts
            tshirt.Name = "NASA";
            tshirt.Name = "NASA2";
            tshirt.Name = "NASA3";

            //Golfer shits
            tshirt.Name = "Golfer1";
            tshirt.Name = "Golfer2";
            tshirt.Name = "Golfer3";


            //Jeans
            pants.Jean = "Polo";
            pants.Jean = "Levis";
            pants.Jean = "Kelso";


            //Formal pants
            pants.FormalPants = "formal1";
            pants.FormalPants = "formal2";
            pants.FormalPants = "formal3";


            //Sizes for Tshirts
            tshirt.Size = "s";
            tshirt.Size = "m";
            tshirt.Size = "L"; 
            
            //Golfer shirts sizes
            tshirt.SizeGolferShirt = "s";
            tshirt.SizeGolferShirt = "m";
            tshirt.SizeGolferShirt = "L";

            //Jeans sizes
            pants.JeansSize = "s";
            pants.JeansSize = "m";
            pants.JeansSize = "L";


            //Formal Pants sizes
            pants.FormalPantsSize = "s";
            pants.FormalPantsSize = "m";
            pants.FormalPantsSize = "L";


            //Setting prices for each size
            if (tshirt.Size.Equals("s"))
            {
                tshirt.Price = 10;//Sets the price to R10

            }

            if (tshirt.Size.Equals("m"))
            {
                tshirt.PriceMedium = 20;//Sets the price to R20
            }

            if (tshirt.Size.Equals("L"))//Sets the price to R30
            {
                tshirt.PriceLarge = 30;
            }


            //Setting prices for each Golfer shirt size
            if (tshirt.SizeGolferShirt.Equals("s"))
            {
                tshirt.PriceGolferSmall = 10;//Sets the price to R10

            }

            if (tshirt.SizeGolferShirt.Equals("m"))
            {
                tshirt.PriceGolferMedium = 20;//Sets the price to R20
            }

            if (tshirt.SizeGolferShirt.Equals("L"))//Sets the price to R30
            {
                tshirt.PriceGolferLarge = 30;
            }

            //Sets the prices for the jeans
            if (pants.Jean.Equals("s"))//Sets the price to R10
            {
                pants.JeansPriceSmall = 10;
            } 
            if (pants.Jean.Equals("m"))//Sets the price to R20
            {
                pants.JeansPriceMedium = 20;
            } 
            if (pants.Jean.Equals("L"))//Sets the price to R30
            {
                pants.JeansPriceLarge = 30;
            }




            //Sets the prices for the Formal pants
            if (pants.FormalPants.Equals("s"))//Sets the price to R10
            {
                pants.FormalPantsPriceSmall = 10;
            }
            if (pants.FormalPants.Equals("m"))//Sets the price to R20
            {
                pants.FormalPantsPriceMedium = 20;
            }
            if (pants.FormalPants.Equals("L"))//Sets the price to R30
            {
                pants.FormalPantsPriceLarge = 30;
            }

            //Saves the Tshir, GolferShirts, Jeasn and FormalPants
            Shirts.Add(tshirt);
            pantsHere.Add(pants);


            //Saves the prices of the shirts
            holdPrices.Add(tshirt.Price); 
            holdPrices.Add(tshirt.PriceMedium); 
            holdPrices.Add(tshirt.PriceLarge);
            holdPrices.Add(tshirt.PriceGolferSmall);
            holdPrices.Add(tshirt.PriceGolferMedium);
            holdPrices.Add(tshirt.PriceGolferLarge);


            //Saves the prices of the Pants
            holdPricesPants.Add(pants.JeansPriceSmall);
            holdPricesPants.Add(pants.JeansPriceMedium);
            holdPricesPants.Add(pants.JeansPriceLarge);

            holdPricesPants.Add(pants.FormalPantsPriceSmall);
            holdPricesPants.Add(pants.FormalPantsPriceMedium);
            holdPricesPants.Add(pants.FormalPantsPriceLarge);

            //Output
            WriteLine($"Your total price is R{basket.getTotalPrice()}");

      
            //for (int i = 0; i < Shirts.Count; i++)
            //{
            //    WriteLine("SHIRTS: " + Shirts[i]);

            //}


        }



    }


    //Basket class as a parent class to Tshirt and Pants class
    public abstract class Basket
    {
        // public string tshirtName, tshirtSize, tshirtPrice;


        public static List<Tshirt> Shirts = new List<Tshirt>();
        public static List<Pants> pantsHere = new List<Pants>();
        public static List<int> holdPrices = new List<int>();

        public static List<int> holdPricesPants = new List<int>();

      

        public abstract int getTotalPrice();


        public class Tshirt : Basket
        {
          
            //Properties
            public string Name
            {
                get;

                set;

            }

            public string Size
            {
                get;
                set;
            }

            public string SizeGolferShirt
            {
                get;
                set;
            }

            int thePrice;
            public int Price
            {

                get { return thePrice; }
                set { thePrice = 0 ; }
            }

            //For medium size tshirt
            public int PriceMedium
            {
                get;
                set;
            }

            //For Large size tshirt
            public int PriceLarge
            {
                get;
                set;
            }

            public int PriceGolferSmall
            {
                get;
                set;
            }



            public int PriceGolferMedium
            {
                get;
                set;
            }

            public int PriceGolferLarge
            {
                get;
                set;
            }


            public override int getTotalPrice()
            {
                int total = 0;
    
               total = holdPrices[0] + holdPrices[1] + holdPrices[2] + holdPrices[3] + holdPrices[4] +
                    holdPricesPants[0] + holdPricesPants[1] + holdPricesPants[2] + holdPricesPants[3] +
                    holdPricesPants[4];

                return total;
               
            }
        }



        //Pants Class
        public class Pants 
        {
            public string Jean
            {
                get;
                set;
            }

              public string FormalPants
            {
                get;
                set;
            }

            public string JeansSize
            {
                get;
                set;
            }
            public string FormalPantsSize
            {
                get;
                set;
            }


            public int JeansPriceSmall
            {
                get;
                set;
            }
            public int JeansPriceMedium
            {
                get;
                set;
            }
            public int JeansPriceLarge
            {
                get;
                set;
            }

            //Formal pants price


            public int FormalPantsPriceSmall
            {
                get;
                set;
            }

            public int FormalPantsPriceMedium
            {
                get;
                set;
            }



            public int FormalPantsPriceLarge
            {
                get;
                set;
            }



        }
    }

}



